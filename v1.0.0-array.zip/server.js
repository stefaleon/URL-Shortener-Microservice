var express = require('express');
var app = express();
var PORT = process.env.PORT || 3000;
var urlExists = require('url-exists');




var shortUrls = [{
	id: 1000, 
	destination: 'http://mashable.com/category/cats/'
}];

var idCounter = 1000;
var validUrl = '';

app.use(express.static('public'));

app.get('/new/*', function (req, res){
	
	console.log('The req.params are:', req.params);
	console.log('req.params[0] is:', req.params[0]);
	console.log('the shortUrls array is:',shortUrls);	
	testUrl = req.params[0];
	
	urlExists(testUrl, function(err, exists) {
		if (err) throw err;
		console.log('exists is', exists );
		if (exists) {
			console.log('awgiouagwaaa is niiiceee!');	
			idCounter++;
			console.log('idCounter is:', idCounter);	
			newShortUrl = { id: idCounter, destination: testUrl };
			console.log('newShortUrl is:', newShortUrl);
			shortUrls.push(newShortUrl);
			console.log('the shortUrls array is now:',shortUrls);	
			res.json({ original_url: testUrl, short_url: 'http://localhost:3000/' + idCounter.toString() });	
		}
		else {
			res.send({error: 'Invalid url.'});
		}
	});
});

app.get('/:id', function (req, res) {	
	var notFound = true;
	console.log ('parseInt(req.params.id) is ' + parseInt(req.params.id));
	console.log ('typeof req.params.id is ' + typeof(req.params.id) );
	shortUrls.forEach(function(shortUrl) {
		console.log (shortUrl);
		if ( shortUrl.id === parseInt(req.params.id) ) {
			console.log ('shortUrl.id is ' + shortUrl.id);
			console.log ('typeof shortUrl.id is ' + typeof(shortUrl.id));
			console.log (shortUrl.id === parseInt(req.params.id));
			console.log ('redirecting');
			notFound = false;
			res.redirect(shortUrl.destination);
		} 		
	});
	if(notFound){
		res.status(404).send("Not found.");
	}	
});



app.listen(PORT, process.env.IP, function(){
    console.log('Server started on port', PORT);
});
